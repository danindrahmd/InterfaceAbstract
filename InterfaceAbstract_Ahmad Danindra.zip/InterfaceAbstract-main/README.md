# InterfaceAbstract
This repo is the part of Oracle Academy course: Java Programming
